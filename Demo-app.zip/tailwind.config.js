/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        "primary-contrast": "#fff",
        gray: {
          "100": "#8e8e94",
          "200": "#191919",
          "300": "rgba(0, 0, 0, 0.6)",
          "400": "rgba(0, 0, 0, 0.23)",
          "500": "rgba(255, 255, 255, 0.2)",
          "600": "rgba(0, 0, 0, 0.4)",
        },
        whitesmoke: {
          "100": "#f8f9fb",
          "200": "#eaeaea",
        },
        orange: {
          "100": "#fba403",
          "200": "#f99a0e",
        },
        darkorange: "#dc880b",
        slategray: "#576074",
        darkslategray: {
          "400": "#434343",
          "500": "#424242",
          "600": "#303030",
        },
        cornflowerblue: {
          "200": "#1262af",
          "300": "#1262ae",
          "400": "rgba(18, 98, 175, 0.06)",
          "500": "rgba(18, 98, 175, 0.05)",
        },
        "studio-darkmode-maincta-457eff": "#457eff",
        lightslategray: "#7e8a97",
        lightgray: "#cecece",
        dimgray: {
          "100": "#646468",
          "200": "#616161",
          "300": "#57575d",
        },
        "text-primary": "rgba(0, 0, 0, 0.87)",
        "action-hover": "rgba(0, 0, 0, 0.04)",
        peru: "#9e6104",
        gainsboro: {
          "200": "#e0e0e0",
          "300": "rgba(226, 226, 226, 0.1)",
        },
        lavender: {
          "100": "#cdddec",
          "200": "#ccdcec",
        },
        darkgray: "#999",
        black: "#000",
        silver: "#bdbdbd",
      },
      spacing: {},
      fontFamily: {
        "typography-body-1": "Roboto",
        "baloo-bhai": "'Baloo Bhai'",
        inter: "Inter",
      },
      borderRadius: {
        "3xs": "10px",
        "8xl": "27px",
        "19xl": "38px",
        "12xl": "31px",
        "45xl": "64px",
      },
    },
    fontSize: {
      base: "16px",
      xl: "20px",
      lg: "18px",
      mini: "15px",
      "11xl": "30px",
      sm: "14px",
      "3xl": "22px",
      "23xl": "42px",
      "13xl": "32px",
      xs: "12px",
      "5xl": "24px",
      "2xl": "21px",
      smi: "13px",
      "42xl": "61px",
      "12xl": "31px",
      "19xl": "38px",
      inherit: "inherit",
    },
    screens: {
      lg: {
        max: "1200px",
      },
      md: {
        max: "1100px",
      },
      sm: {
        max: "650px",
      },
      mq428small: {
        raw: "screen and (max-width: 428px)",
      },
    },
  },
  corePlugins: {
    preflight: false,
  },
};
